import numpy as np
class MonteCarloAgent:
    def run(self,returns,n=1000):
        return [np.random.choice(returns,len(returns),replace=True) for _ in range(n)]
