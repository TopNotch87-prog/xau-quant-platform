import yfinance as yf
class DataAgent:
    def download(self,symbol='GC=F',period='5y',interval='1d'):
        return yf.download(symbol,period=period,interval=interval)
