class WalkForwardOptimizer:
    def optimize(self,data):
        return {'status':'todo'}
