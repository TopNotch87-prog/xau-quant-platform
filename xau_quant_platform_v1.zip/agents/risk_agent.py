import numpy as np
class RiskAgent:
    def sharpe(self,r):
        return (r.mean()/r.std())*np.sqrt(252)
