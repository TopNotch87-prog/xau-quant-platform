import matplotlib.pyplot as plt
class ReportingAgent:
    def equity_curve(self,series,path='reports/equity_curve.png'):
        series.plot()
        plt.savefig(path)
