class StrategyAgent:
    def choose(self,regime):
        return 'trend_following'
